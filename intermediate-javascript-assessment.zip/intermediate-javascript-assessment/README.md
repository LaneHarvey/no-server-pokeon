utilities
=========

In the src/underscore_tests.js file there are a bunch of empty function definitions. Your job, is to fill out each function definition so that the tests in SpecRunner.html pass. 

Open up SpecRunner.html in your browser to see which tests are passing and failing. As you write the function definiitons in the underscore_tests.js file, the tests will begin passing.

## Copyright

© DevMountain LLC, 2016. Unauthorized use and/or duplication of this material without express and written permission from DevMountain, LLC is strictly prohibited. Excerpts and links may be used, provided that full and clear credit is given to DevMountain with appropriate and specific direction to the original content.
